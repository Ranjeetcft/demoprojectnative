export const API_URL = "https://golden-reel-api.codesfortomorrow.com";
//export const API_URL =
// "https://03d0-2401-4900-8822-e71c-d12-6ad7-ed58-b8c3.ngrok-free.app";
