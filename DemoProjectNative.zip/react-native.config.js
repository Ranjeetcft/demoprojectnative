module.exports = {
  assets: ["./assets/fonts/"], // Path to your assets folder
};
